import java.io.IOException;

        import org.jsoup.Jsoup;
        import org.jsoup.nodes.Document;

public class Scraper {

    public static void main(String[] args) {
        try {
           //requisicao na pagina do produto
            Document doc = Jsoup.connect("https://www.americanas.com.br/produto/134395087/notebook-asus-x512fa-br569t-8a-intel-core-i5-8gb-1tb-w10-15-6-prata?pfm_carac=notebook&pfm_index=3&pfm_page=search&pfm_pos=grid&pfm_type=search_page%20&sellerId&sellerid").get();
            //Captura do codigo do produto
            String codigo = doc.select("span[class=TextUI-sc-1hrwx40-0 brNcBx]").text();
            System.out.println("Código do produto: = " + codigo + "\n");
            //Captura do titulo do anuncio do produto
            String titulo = doc.select("h1[class=product-title__TitleUI-sc-116vf1e-1 fIAiYD TitleH1-c6mv26-0 iEwJxn]").text();
            System.out.println("Título do anúncio:  = " + titulo + "\n");
            //Captura do preco
            String preco = doc.select("span[class=sales-price main-offer__SalesPrice-sc-1oo1w8r-1 haZIvY TextUI-sc-1hrwx40-0 doPTSH]").text();
            System.out.println("Preço: = " + preco + "\n");
            //Captura do vendedor
            String vendedor = doc.select("span[class=seller-00776574000660 TextUI-sc-1hrwx40-0 beNsgm]").text();
            System.out.println("Vendedor: = " + vendedor + "\n");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}